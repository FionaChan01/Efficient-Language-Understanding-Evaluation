import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

const routes = [{
    path: '/',
    redirect: "login"
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('../views/Login/index.vue')
  },
  {
    path: '/homepage',
    name: 'Homepage',
    component: () => import('../views/Homepage/index.vue')
  },
  {
    path: "/startTask",
    name: "startTask",
    component: () => import('../views/startTask/index.vue')
  },
  {
    path: "/caseStorage",
    name: "caseStorage",
    component: () => import('../views/caseStorage/index.vue')
  },
  {
    path: "/testHistory",
    name: "testHistory",
    component: () => import('../views/testHistory/index.vue')
  },
  {
    path: "/compareHistory",
    name: "compareHistory",
    component: () => import('../views/compareHistory/index.vue')
  },
  {
    path: "/databaseManager",
    name: "databaseManager",
    component: () => import('../views/databaseManager/index.vue')
  },
]

const router = new VueRouter({
  routes
})

export default router